(function() {
    'use strict';

    angular
        .module('app.employee')
        .constant('REQUEST', {
            'Employees' : '/api/v1/employees'
        });
})();