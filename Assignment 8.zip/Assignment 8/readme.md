- When you open the node portable exe. enter this command

- npm install -g nodemon

- go the the following folder you plan on working on.

- e.g. C://../../../week8/demo

- then you can run the command nodemon server_start.js (or what ever your start app file is)

- you should be able to update and not have to restart the server.